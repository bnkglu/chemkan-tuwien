"""Place the poster body into the TU Wien Informatics A0 template and write the header.

The header keeps the template's fonts, sizes, colour, baselines and alignment (measured from
the template PDF); only the placeholder strings are replaced. The top-right logo slot gets
the same dashed LOGO PLACEHOLDER as the previous poster version.

    python compose.py <template.pdf> <fonts-dir> <body.pdf> <out.pdf>
"""
import sys
from pathlib import Path
import pymupdf as fitz

TPL, FONTS, BODY, OUT = (Path(a) for a in sys.argv[1:5])
LIGHT, MEDIUM = str(FONTS / 'Roboto-Light.ttf'), str(FONTS / 'Roboto-Medium.ttf')
INK = (0x1d / 255, 0x1d / 255, 0x1b / 255)
RIGHT = 2316.15

doc = fitz.open(TPL)
page = doc[0]

# content area: remove the template's info text and guide frame
page.add_redact_annot(fitz.Rect(30, 590, 2366, 3350), fill=False)
page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE, graphics=fitz.PDF_REDACT_LINE_ART_REMOVE_IF_COVERED,
                      text=fitz.PDF_REDACT_TEXT_REMOVE)
# header placeholders (text only; grey band and faculty logo untouched)
keep = 'TU Wien Informatics'
for b in page.get_text('dict')['blocks']:
    for l in b.get('lines', []):
        for s in l['spans']:
            if s['text'].strip() and s['text'].strip() != keep:
                page.add_redact_annot(fitz.Rect(s['bbox']), fill=False)
page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE, graphics=fitz.PDF_REDACT_LINE_ART_NONE,
                      text=fitz.PDF_REDACT_TEXT_REMOVE)
left = [s['text'] for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans'] if s['text'].strip()]
assert left == [keep], left

page.insert_font(fontname='RobL', fontfile=LIGHT)
page.insert_font(fontname='RobM', fontfile=MEDIUM)
fl, fmd = fitz.Font(fontfile=LIGHT), fitz.Font(fontfile=MEDIUM)


def put(text, x, y, size, medium=False, right=False, color=INK):
    f = fmd if medium else fl
    if right:
        x = RIGHT - f.text_length(text, size)
    page.insert_text((x, y), text, fontname='RobM' if medium else 'RobL', fontsize=size, color=color)
    return x


# Title: style "Title" (Roboto Medium 54 pt, baselines 328.17 / 392.97)
put('Modeling Chemical Kinetics with ChemKANs:', 224.65, 328.17, 54, medium=True)
put('Reproduction in PyTorch and Extension to Methane', 224.65, 392.97, 54, medium=True)
# Name and programme: style "Name and Master's Program" (Roboto Light 36 pt)
put('Hasan Berke Bankoglu', 224.65, 467.33, 36)
prog = 'Master’s Programme Data Science · Interdisciplinary Project'
prog_end = 224.65 + fl.text_length(prog, 36)
put(prog, 224.65, 518.82, 36)
# Right block: style "Info on Institute/RU/Supervisor" (Roboto Light 28 pt, right-aligned,
# 35 pt leading) under the template's own "TU Wien Informatics" line. Supervisor first,
# co-supervisor second, each followed by his own unit.
lines = ['Supervisor: Ass. Prof. DI Dr. Markus Bösenhofer',
         'Institute of Chemical, Environmental and Bioscience Engineering',
         'Co-Supervisor: Univ.-Prof. Dr. Thomas Gärtner',
         'Institute of Information Systems Engineering, Research Unit Machine Learning']
xs = [put(t, None, 413.82 + 35 * i, 28, right=True) for i, t in enumerate(lines)]
assert min(xs) > prog_end + 30, (xs, prog_end)

# top-right logo slot: placeholder, unchanged from the previous version
MM = 72 / 25.4
logo = fitz.Rect(RIGHT - 200 * MM, 70, RIGHT, 70 + 60 * MM)
page.draw_rect(logo, color=(0.55, 0.56, 0.57), width=1.5, dashes='[8 6] 0')
for k, t in enumerate(['LOGO PLACEHOLDER', 'main supervisor: faculty / research group', 'max. 200 × 60 mm, right-aligned']):
    w = fl.text_length(t, 22)
    page.insert_text((logo.x0 + (logo.width - w) / 2, logo.y0 + 62 + 30 * k), t, fontname='RobL', fontsize=22,
                     color=(0.45, 0.47, 0.48))

# body: 12.7 mm from the header band and from the trimmed page edges
body = fitz.open(BODY)
r = body[0].rect
area = fitz.Rect(44, 612, 44 + r.width, 612 + r.height)
trim, m = page.trimbox, 36.0
assert area.x0 >= trim.x0 + m - 0.5 and area.x1 <= trim.x1 - m + 0.5 and area.y1 <= trim.y1 - m + 0.5 \
    and area.y0 >= 572.6 + m - 0.5, (area, trim)
page.show_pdf_page(area, body, 0)

now = fitz.get_pdf_now()
doc.set_metadata({'title': 'Modeling Chemical Kinetics with ChemKANs: Reproduction in PyTorch and Extension to Methane',
                  'author': 'Hasan Berke Bankoglu', 'subject': 'Interdisciplinary Project in Data Science, TU Wien',
                  'creator': '', 'producer': '', 'keywords': '', 'creationDate': now, 'modDate': now})
doc.del_xml_metadata()
doc.save(OUT, garbage=4, deflate=True, clean=True)
print(OUT, round(OUT.stat().st_size / 1e6, 2), 'MB')

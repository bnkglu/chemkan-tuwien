"""Read-only check of the MG rate-parity breakdown (biodiesel, noise-free 156-parameter model).

Evaluates the instantaneous species rates of the checkpoint at every reference state of the
recorded dataset, without PyTorch: the checkpoint's tensors are read directly from the .pt
archive and the network is evaluated in NumPy, following the release's own definitions
(reference_components.build_core, kan/rbf.py, kan/layers.py, interpretability/biodiesel.py).
The reference rates come from the data generator's kinetics (released-code reaction orders).
The NumPy evaluation is accepted only if it reproduces all 12 recorded RMSEs in
results/biodiesel/interpretability/summary.json.

    python verify_mg_initial_states.py <release-root> [out.json]
"""
import io
import json
import pickle
import sys
import zipfile
from pathlib import Path

import numpy as np

REL = Path(sys.argv[1]).resolve()
RUN = REL / 'results/biodiesel/chemkan_figure_runs/fig05/chemkan_noise00_seed0'
SPECIES = ['TG', 'ROH', 'DG', 'MG', 'GL', 'RCO2R']


# ---------------------------------------------------------------- torch-free checkpoint reader
def load_pt(path):
    zf = zipfile.ZipFile(path)
    root = zf.namelist()[0].split('/')[0]
    DT = {'DoubleStorage': np.float64, 'FloatStorage': np.float32, 'LongStorage': np.int64,
          'IntStorage': np.int32, 'BoolStorage': np.bool_, 'HalfStorage': np.float16}

    class _Stub:
        def __init__(self, *a, **k):
            pass

        def __setstate__(self, s):
            self.__dict__['state'] = s

    def rebuild(storage, offset, size, stride, *a):
        dt, key = storage
        buf = np.frombuffer(zf.read(f'{root}/data/{key}'), dtype=dt)
        if not size:
            return buf[offset].copy()
        st = [s * buf.itemsize for s in stride]
        return np.lib.stride_tricks.as_strided(buf[offset:], shape=size, strides=st).copy()

    class U(pickle.Unpickler):
        def find_class(self, mod, name):
            if mod == 'torch._utils' and name == '_rebuild_tensor_v2':
                return rebuild
            if mod == 'torch._utils' and name == '_rebuild_parameter':
                return lambda data, *a: data
            if mod == 'torch' and name in DT:
                return name
            if mod == 'collections' and name == 'OrderedDict':
                import collections
                return collections.OrderedDict
            try:
                return super().find_class(mod, name)
            except Exception:
                return type(name, (_Stub,), {})

        def persistent_load(self, pid):
            _, stype, key, _loc, _n = pid
            return (DT[stype if isinstance(stype, str) else stype.__name__], key)

    return U(io.BytesIO(zf.read(f'{root}/data.pkl'))).load()


ck = load_pt(RUN / 'checkpoint_final.pt')
cfg = ck['config']
st = {k: np.asarray(v, np.float64) for k, v in ck['model_state'].items()}
assert sum(v.size for k, v in st.items() if 'w_' in k) == 156, {k: v.shape for k, v in st.items()}
W1, W2 = st['add.edges.w_rbf'], st['lean.edges.w_rbf']          # (4, 7, 3), (6, 4, 3)
C = np.array([-1.0, 0.0, 1.0])
src = cfg['data_source']
u_min = np.array(src['species_min'] + [src['T_min']]); u_max = np.array(src['species_max'] + [src['T_max']])
div = float(cfg.get('rhs_divisor', {}).get('value', 50.0))
n_mu = 2


def rbf(x):                                   # Gaussian exp(-r^2 / (2 h^2)), h = 1/sqrt(2)
    return np.exp(-(x[..., None] - C) ** 2)


def chemkan_rates(u):
    z = (u - u_min) / (u_max - u_min)
    h = np.einsum('bik,oik->boi', rbf(z), W1).sum(-1)                  # additive layer, no input tanh
    g = np.einsum('bik,oik->boi', rbf(np.tanh(h)), W2)                # LeanKAN edges, tanh input
    out = g[..., :n_mu].prod(-1) + g[..., n_mu:].sum(-1)
    return out * (u_max - u_min)[:6] / div


# ---------------------------------------------------------------- reference kinetics (data generator)
sys.path.insert(0, str(REL / 'chemkan/scripts/data_gen'))
import generate_biodiesel as gb  # noqa: E402

d = np.load(REL / 'chemkan/data/generated/biodiesel_v2.npz')
res, LOG = {}, []
pooled = {}
summ = json.load(open(REL / 'results/biodiesel/interpretability/summary.json'))['rate_parity_all_reference_states']
for split in ('train', 'test'):
    y, T = d[f'{split}_states'], d[f'{split}_T'].astype(float)
    u = np.concatenate([y, np.broadcast_to(T[:, None, None], y.shape[:2] + (1,))], -1)
    t_idx = np.broadcast_to(np.arange(y.shape[1]), y.shape[:2]).reshape(-1)
    u = u.reshape(-1, 7)
    r_true = np.array([gb.rhs(0.0, row[:6], gb.rate_constants(row[6], 'released_code')) for row in u])
    r_kan = chemkan_rates(u)
    for i, s in enumerate(SPECIES):
        rm = np.sqrt(np.mean((r_kan[:, i] - r_true[:, i]) ** 2))
        rec = summ[s][split]['rmse_mol_per_L_s']
        assert abs(rm - rec) <= 1e-6 * rec, (s, split, rm, rec)
    LOG.append(f'{split}: NumPy evaluation reproduces all 6 recorded RMSEs (rel. diff < 1e-6), n = {len(u)}')
    mg_t, mg_k = r_true[:, 3], r_kan[:, 3]
    zero = mg_t == 0.0
    se = (mg_k - mg_t) ** 2
    rms = np.sqrt(np.mean(mg_t ** 2))
    res[split] = {
        'n_states': int(len(u)),
        'n_zero_reference_MG_rate': int(zero.sum()),
        'zero_states_are_t0': bool(np.all(t_idx[zero] == 0) and zero.sum() == y.shape[0]),
        'chemkan_MG_rate_at_zero_states_min_max': [float(mg_k[zero].min()), float(mg_k[zero].max())],
        'all_positive_at_zero_states': bool(np.all(mg_k[zero] > 0)),
        'relative_rmse_all': float(np.sqrt(se.mean()) / rms),
        'relative_rmse_recorded': summ['MG'][split]['relative_rmse'],
        'relative_rmse_excluding_t0': float(np.sqrt(se[~zero].mean()) / np.sqrt(np.mean(mg_t[~zero] ** 2))),
        'share_of_squared_error_at_t0': float(se[zero].sum() / se.sum()),
    }
    pooled.setdefault('se', []).append(se); pooled.setdefault('zero', []).append(zero)
se, zero = np.concatenate(pooled['se']), np.concatenate(pooled['zero'])
res['pooled'] = {'n_states': int(len(se)), 'n_zero_reference_MG_rate': int(zero.sum()),
                 'share_of_squared_error_at_t0': float(se[zero].sum() / se.sum())}
res['note'] = ('relative RMSE = RMSE / RMS(reference rate), as in interpretability/biodiesel.py; '
               'excluding t0 the RMS of the reference is recomputed over the remaining states')
print('\n'.join(LOG)); print(json.dumps(res, indent=1))
if len(sys.argv) > 2:
    json.dump({'checks': LOG, **res}, open(sys.argv[2], 'w'), indent=1)

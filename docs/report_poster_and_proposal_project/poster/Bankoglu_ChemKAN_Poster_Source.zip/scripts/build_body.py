"""Fill build/body.html with numbers read from the release artifacts and render body.pdf.

Every placeholder value is computed here from a named file (see VERIFY in the comments), so
the poster text and the recorded results cannot drift apart.

    python build_body.py <release-root> <build-dir>
"""
import csv, json, re, statistics, sys
from pathlib import Path

REL, B = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
E = REL / 'results'
V = json.load(open(B / 'verify.json'))          # produced by verify.py from the same release


def sci(x, d=1):
    m, e = f'{x:.{d}e}'.split('e')
    e = int(e)
    return f'{m}·10<sup>−{abs(e)}</sup>' if e < 0 else f'{m}·10<sup>{e}</sup>'


def pct(x, d=1):
    return f'{100 * x:.{d}f}&nbsp;%'


def ms(v):
    return (f'{v:.2f}' if v < 10 else f'{v:.1f}' if v < 100 else f'{v:.0f}') + ' ms'


def x_(v):
    return (f'{v:.3f}' if v < 0.1 else f'{v:.2f}' if v < 1 else f'{v:.1f}') + '×'


bio = V['bio_scaling']
rr = V['bio_rate_parity']
others = [v for k, v in rr.items() if k != 'MG']
lo = min(min(v[0], v[1]) for v in others); hi = max(max(v[0], v[1]) for v in others)
bench = V['bench']
H, M = bench['hydrogen'], bench['methane']
bb = bench['biodiesel']

# methane ignition statistics of the 36-condition figure: the methane_extension notebook's
# saved output for that figure (501-point grid), read from the notebook itself
nb = json.load(open(REL / 'chemkan/notebooks/methane_extension.ipynb'))
ign_txt = None
for c in nb['cells']:
    if c['cell_type'] == 'code' and 'methane_ignition_delay_rise_S2_epoch' in ''.join(c['source']):
        for o in c.get('outputs', []):
            t = ''.join(o.get('text', ''))
            if '|delay error|' in t:
                ign_txt = t
assert ign_txt, 'methane ignition output not found'
mm = re.search(r'median ([\d.]+)%, max ([\d.]+)%', ign_txt)
ch4_ign_med, ch4_ign_max = float(mm.group(1)), float(mm.group(2))

PD = __import__('numpy').load(B / 'fig' / 'poster_data.npz')   # written by poster_data.py
assert abs(float(PD['h2_ign_med']) - V['h2_ign'][1]) < 1e-9

vals = {
    'h2_ign_max': pct(float(PD['h2_ign_max']), 1),
    'bio_order': f"{bio['order_train']:.2f} / {bio['order_test']:.2f}",
    'bio_small': f"{sci(bio['smallest'][0], 1)} / {sci(bio['smallest'][1], 1)}",
    'bio_inc1': sci(V['bio_inc_0_1'], 2), 'bio_inc5': sci(V['bio_inc_0_5'], 2),
    'bio_ck_ratio': f"{V['bio_ck_ratio_15_0']:.2f}",
    'bio_dn_over_ck_15': f"{V['bio_dn_over_ck_15']:.2f}",
    'bio_dn_over_ck_10': f"{V['bio_dn_over_ck_10']:.2f}×",
    'h2_heldout': sci(V['h2_heldout_441csv']),
    'h2_ign': pct(V['h2_ign'][1], 2),
    'h2_441_median': sci(V['h2_441'][3]),
    'h2_441_max': sci(V['h2_441'][5]),
    'ch4_heldout': sci(V['ch4_441']['held_out_1550K_phi1.3'], 2),
    'ch4_ign36': f'{ch4_ign_med:.1f}&nbsp;%', 'ch4_ign36_max': f'{ch4_ign_max:.1f}&nbsp;%',
    'ch4_36_median': sci(V['ch4_36_median_mse'], 2),
    'ch4_hist_a': sci(V['ch4_hist_median_170001_180000'], 2),
    'ch4_hist_b': sci(V['ch4_hist_median_190001_200000'], 2),
    'ch4_unseen': sci(V['ch4_441']['unseen_406']['median']),
    'ch4_train': sci(V['ch4_441']['training_35']['median']),
    'ch4_max': sci(V['ch4_441']['unseen_406']['max'], 2),
    'jl_vs_pt': f"{H['pt'] / H['jl']:.0f}×", 'h2_jl': ms(H['jl']), 'h2_pt': ms(H['pt']),
    'h2_jl_x': f"{H['jl_x'][0]:.1f}×", 'ch4_jl_x': f"{M['jl_x'][0]:.1f}×",
    'bio_jl_ref': ms(bb['reference|Julia|released kinetics, CVODE_BDF|1e-10 / 1e-12']),
    'bio_jl_ck': ms(bb['ChemKAN|Julia|OrdinaryDiffEq Tsit5|1e-10 / 1e-12']),
    'rr_lo': f'{lo:.2f}', 'rr_hi': f'{hi:.2f}', 'rr_mg': f"{rr['MG'][0]:.3f} / {rr['MG'][1]:.3f}",
}
assert abs(H['mse_36'] - H['mse_36_pt']) / H['mse_36'] < 1e-3 and abs(M['mse_36'] - M['mse_36_pt']) / M['mse_36'] < 1e-3


def spd(k, S):
    return f"{x_(S[k][0])} / {x_(S[k][1])}"


vals['speed_table'] = f"""<table class="speed">
    <tr class="grp"><th></th><th colspan="2">H<sub>2</sub>–air · 29 reactions</th><th colspan="2">CH<sub>4</sub>–air · 325 reactions</th></tr>
    <tr><th>Method</th><th class="num">time</th><th class="num">speed-up</th><th class="num">time</th><th class="num">speed-up</th></tr>
    <tr><td>Cantera (CVODES) [5]</td><td class="num">{ms(H['cantera'])}</td><td class="num">reference</td><td class="num">{ms(M['cantera'])}</td><td class="num">reference</td></tr>
    <tr><td>Arrhenius.jl (CVODE) [7]</td><td class="num">{ms(H['arrh'])}</td><td class="num">reference</td><td class="num">{ms(M['arrh'])}</td><td class="num">reference</td></tr>
    <tr><td>ChemKAN · PyTorch</td><td class="num">{ms(H['pt'])}</td><td class="num">{spd('pt_x', H)}</td><td class="num">{ms(M['pt'])}</td><td class="num">{spd('pt_x', M)}</td></tr>
    <tr class="ck"><td><b>ChemKAN · Julia port</b></td><td class="num"><b>{ms(H['jl'])}</b></td><td class="num"><b>{spd('jl_x', H)}</b></td><td class="num"><b>{ms(M['jl'])}</b></td><td class="num"><b>{spd('jl_x', M)}</b></td></tr>
  </table>"""

# Encode the canonical repository URL in the existing vector QR-code slot.
URL = 'https://github.com/bnkglu/chemkan-tuwien'
try:
    import segno
    q = segno.make(URL, error='m').svg_inline(border=0, dark='#1d1d1b', omitsize=True)
    vals['qr'] = q.replace('<svg ', '<svg width="96pt" height="96pt" ', 1)
except ImportError:
    # Fallback for environments where the optional segno package is absent:
    # qrcode, or else OpenCV's QR encoder.
    try:
        import qrcode
        q = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=1, border=0)
        q.add_data(URL)
        q.make(fit=True)
        mat = q.get_matrix()
    except ImportError:
        import cv2
        import numpy as np
        prm = cv2.QRCodeEncoder.Params()
        prm.correction_level = cv2.QRCodeEncoder_CORRECT_LEVEL_M
        img = cv2.QRCodeEncoder.create(prm).encode(URL)        # 1 px per module plus a white margin
        dark = np.argwhere(img == 0)
        (r0, c0), (r1, c1) = dark.min(0), dark.max(0)
        img = img[r0:r1 + 1, c0:c1 + 1]                          # trim the margin exactly
        mat = [[px == 0 for px in row] for row in img]
    n = len(mat)
    rects = ''.join(f'<rect x="{j}" y="{i}" width="1" height="1"/>'
                    for i,row in enumerate(mat) for j,black in enumerate(row) if black)
    vals['qr'] = (f'<svg xmlns="http://www.w3.org/2000/svg" width="96pt" height="96pt" '
                  f'viewBox="0 0 {n} {n}" shape-rendering="crispEdges">'
                  f'<g fill="#1d1d1b">{rects}</g></svg>')

html = (B / 'body.html').read_text()
for k, v in vals.items():
    html = html.replace('{{' + k + '}}', v)
left = re.findall(r'\{\{[^}]+\}\}', html)
assert not left, left
(B / 'body_filled.html').write_text(html)
json.dump({k: v for k, v in vals.items() if k not in ('speed_table', 'qr')}, open(B / 'poster_values.json', 'w'), indent=1, ensure_ascii=False)

# Prefer the original Chromium-based workflow where available. In restricted
# environments without the bundled browser or file access, fall back to
# WeasyPrint (the poster dimensions and CSS remain unchanged).
try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        br = p.chromium.launch()
        pg = br.new_page(viewport={'width': 3075, 'height': 3632})
        pg.goto((B / 'body_filled.html').as_uri())
        pg.wait_for_load_state('networkidle')
        pg.evaluate('document.fonts.ready')
        pg.pdf(path=str(B / 'body.pdf'), width=f'{2306/72:.5f}in',
               height=f'{2724/72:.5f}in', print_background=True,
               margin={'top':'0','bottom':'0','left':'0','right':'0'},
               prefer_css_page_size=True)
        br.close()
    print('Rendered with Chromium:', B / 'body.pdf')
except Exception as exc:
    from weasyprint import HTML
    print('Chromium rendering unavailable; using WeasyPrint:', str(exc)[:160])
    HTML(filename=str(B / 'body_filled.html'),
         base_url=(B / 'body_filled.html').as_uri()).write_pdf(str(B / 'body.pdf'))
    print('Rendered with WeasyPrint:', B / 'body.pdf')

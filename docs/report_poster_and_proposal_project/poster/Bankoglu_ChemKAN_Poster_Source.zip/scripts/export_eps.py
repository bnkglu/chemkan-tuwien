"""Export the poster PDF as EPS (vector), for print shops that ask for EPS.

PostScript has no transparency, and poppler's pdftops rasterizes the whole page if any is
present. The only transparency in the poster is the alpha channel (SMask) of the two
rate-parity scatter images; each is composited onto a rendering of what lies beneath it
(axes, parity line) in a temporary copy, then pdftops -eps writes the EPS with text and
vector graphics kept as vectors and fonts embedded.

    python export_eps.py <poster.pdf> <out.eps> [flattened_check.pdf]
"""
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path

import numpy as np
import pikepdf
from pikepdf import PdfImage

SRC, OUT = sys.argv[1:3]
KEEP = sys.argv[3] if len(sys.argv) > 3 else None    # optional: also save the flattened PDF
pdf = pikepdf.open(SRC)


def alpha_images(doc):
    out = []
    for page in doc.pages:
        stack = list(page.Resources.XObject.values())
        while stack:
            o = stack.pop()
            if o.get('/Subtype') == '/Form' and '/Resources' in o and '/XObject' in o.Resources:
                stack.extend(o.Resources.XObject.values())
            if o.get('/Subtype') == '/Image' and '/SMask' in o and o.objgen not in [x.objgen for x in out]:
                out.append(o)
    return out


imgs = alpha_images(pdf)
# where each image sits on the page (pdfplumber reports placed images with their stream object id)
import pdfplumber
placed = {}
with pdfplumber.open(SRC) as pp:
    p0 = pp.pages[0]
    for im in p0.images:
        placed[im['stream'].objid] = (im['x0'], im['top'], im['x1'], im['bottom'])
# background beneath the images: render the page with these images made fully transparent
with tempfile.TemporaryDirectory() as td:
    bg_pdf = pikepdf.open(SRC)
    for o in alpha_images(bg_pdf):
        o.SMask.write(bytes(len(o.SMask.read_bytes())), filter=None)
        for k in ('/Filter', '/DecodeParms'):
            if k in o.SMask:
                del o.SMask[k]
    bg_pdf.save(Path(td) / 'bg.pdf')
    n = 0
    for o in imgs:
        x0, top, x1, bot = placed[o.objgen[0]]
        rgb = PdfImage(o).as_pil_image().convert('RGB')
        W, H = rgb.size
        dpi = 72 * W / (x1 - x0)
        subprocess.run(['pdftoppm', '-r', f'{dpi:.6f}', '-png', '-singlefile', '-x', str(round(x0 * dpi / 72)),
                        '-y', str(round(top * dpi / 72)), '-W', str(W), '-H', str(H),
                        str(Path(td) / 'bg.pdf'), str(Path(td) / 'bg')], check=True)
        from PIL import Image
        bg = np.asarray(Image.open(Path(td) / 'bg.png').convert('RGB').resize((W, H)), float)
        a = np.asarray(PdfImage(o.SMask).as_pil_image().convert('L'), float)[..., None] / 255
        # the reference: the same region of the original page as rendered (with transparency)
        subprocess.run(['pdftoppm', '-r', f'{dpi:.6f}', '-png', '-singlefile', '-x', str(round(x0 * dpi / 72)),
                        '-y', str(round(top * dpi / 72)), '-W', str(W), '-H', str(H),
                        SRC, str(Path(td) / 'ref')], check=True)
        ref = np.asarray(Image.open(Path(td) / 'ref.png').convert('RGB').resize((W, H)), float)
        # the image may be placed flipped; use the orientation whose composite reproduces the page
        cands = []
        for flip_y in (False, True):
            for flip_x in (False, True):
                b_ = bg[::-1] if flip_y else bg
                b_ = b_[:, ::-1] if flip_x else b_
                im_ = np.asarray(rgb, float); a_ = a
                comp = im_ * a_ + b_ * (1 - a_)
                comp_page = comp[::-1] if flip_y else comp
                comp_page = comp_page[:, ::-1] if flip_x else comp_page
                cands.append((np.abs(comp_page - ref).mean(), comp))
        err, comp = min(cands, key=lambda c: c[0])
        assert err < 2.0, err
        flat = comp.round().astype(np.uint8)
        o.write(zlib.compress(flat.tobytes()), filter=pikepdf.Name.FlateDecode)
        o.ColorSpace = pikepdf.Name.DeviceRGB
        o.BitsPerComponent = 8
        for k in ('/SMask', '/DecodeParms', '/Decode'):
            if k in o:
                del o[k]
        n += 1
with tempfile.TemporaryDirectory() as td:
    tmp = Path(td) / 'flat.pdf'
    pdf.save(tmp)
    if KEEP:
        pdf.save(KEEP)
    subprocess.run(['pdftops', '-eps', '-level3', str(tmp), OUT], check=True)
eps = Path(OUT).read_bytes()
full = eps.count(b'/Width 99')                # a full-page raster would be ~9980 px wide
print(f'flattened {n} image alpha channel(s); wrote {OUT} ({len(eps) / 1e6:.1f} MB); full-page rasters: {full}')
assert full == 0

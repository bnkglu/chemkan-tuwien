"""Draw the poster's figures at their printed size from build/fig/poster_data.npz.

Each figure is drawn at exactly the width it occupies on the A0 poster (sizes in pt), in the
poster's Roboto, so text in the plots prints at 17-22 pt. Output: build/fig/*.svg (vector).

    python make_poster_figures.py <poster_data.npz> <fonts-dir> <out-dir>
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib import font_manager  # noqa: E402
from matplotlib.colors import LogNorm  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

D = np.load(sys.argv[1])
FONTS, OUT = Path(sys.argv[2]), Path(sys.argv[3])
OUT.mkdir(parents=True, exist_ok=True)
for f in FONTS.glob('*.ttf'):
    font_manager.fontManager.addfont(str(f))

INK, INK2, GRID = '#1d1d1b', '#4a4f51', '#d5dadc'
TU, ORANGE, RED, GREY = '#006699', '#d98c00', '#e2453c', '#9aa0a3'
FS, TICK, LEG = 21, 19, 18          # pt at print size
plt.rcParams.update({
    'font.family': 'Roboto Light', 'font.size': FS,
    'axes.labelsize': FS, 'axes.titlesize': FS,
    'xtick.labelsize': TICK, 'ytick.labelsize': TICK, 'legend.fontsize': LEG,
    'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
    'text.color': INK, 'axes.linewidth': 1.3, 'xtick.major.width': 1.3, 'ytick.major.width': 1.3,
    'xtick.major.size': 5, 'ytick.major.size': 5, 'xtick.minor.size': 3, 'ytick.minor.size': 3,
    'axes.spines.top': False, 'axes.spines.right': False, 'lines.linewidth': 3,
    'legend.frameon': False, 'legend.handlelength': 1.6, 'legend.borderaxespad': 0.2,
    'svg.fonttype': 'path', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Roboto Light',
    'mathtext.it': 'Roboto Light:italic', 'mathtext.bf': 'Roboto Medium',
    'axes.labelpad': 4, 'xtick.major.pad': 4, 'ytick.major.pad': 4,
})


def fig(w_pt, h_pt):
    return plt.figure(figsize=(w_pt / 72, h_pt / 72))


def save(f, name):
    f.savefig(OUT / f'{name}.svg', dpi=300, transparent=False, facecolor='white')
    f.savefig(OUT / f'{name}.png', dpi=300, facecolor='white')
    plt.close(f)
    print('wrote', name)


def blues(n, lo=0.35, hi=0.95):
    return [plt.get_cmap('Blues')(v) for v in np.linspace(lo, hi, n)]


# ================================================================ biodiesel Fig. 6 style
def biodiesel():
    t, sp = D['bio_t'], [str(s).replace('₂', '$_2$') for s in D['bio_species']]
    f = fig(736, 360)
    gs = f.add_gridspec(2, 3, left=0.09, right=0.975, top=0.865, bottom=0.135, wspace=0.32, hspace=0.36)
    for k in range(6):
        ax = f.add_subplot(gs[k // 3, k % 3])
        ax.scatter(t, D['bio_noisy'][:, k], s=22, color=GREY, lw=0, zorder=1)
        ax.plot(t, D['bio_truth'][:, k], color=INK, lw=2.6, zorder=2)
        ax.plot(t, D['bio_chemkan'][:, k], color=TU, lw=3.0, zorder=3)
        ax.plot(t, D['bio_deeponet'][:, k], color=ORANGE, lw=3.0, ls=(0, (3.2, 1.6)), zorder=4)
        ax.text(0.03, 1.0, sp[k], transform=ax.transAxes, fontsize=FS, fontfamily='Roboto Medium', va='bottom', ha='left')
        ax.set_xlim(-0.8, 30.8); ax.set_xticks([0, 10, 20, 30])
        ax.locator_params(axis='y', nbins=4)
        if k >= 3:
            ax.set_xlabel('t [s]', labelpad=0)
        else:
            ax.set_xticklabels([])
        if k % 3 == 0:
            ax.set_ylabel('c [mol L$^{-1}$]')
    h = [Line2D([], [], color=GREY, marker='o', ls='', ms=6), Line2D([], [], color=INK, lw=2.6),
         Line2D([], [], color=TU, lw=3), Line2D([], [], color=ORANGE, lw=3, ls=(0, (3.2, 1.6)))]
    f.legend(h, ['15 % noisy data', 'truth', 'ChemKAN', 'DeepONet'], loc='upper center', ncol=4,
             bbox_to_anchor=(0.54, 1.005), columnspacing=1.4, handletextpad=0.5)
    save(f, 'bio_profiles')


# ================================================================ trajectories (T + species)
def traj_axes(a1, a2, sysn, species, cols, every, tmax, xt, ylimT, label_pos, legend_loc='lower right'):
    t = D[f'{sysn}_t'] * 1e3
    ref, pr = D[f'{sysn}_ref'], D[f'{sysn}_pred']
    sl = [str(s) for s in D[f'{sysn}_species']]
    a1.plot(t, pr[:, -1], color=TU, lw=3, zorder=2, label='ChemKAN')
    a1.plot(t[::every], ref[::every, -1], ls='', marker='o', ms=6.5, mfc='white', mec=INK, mew=1.5,
            zorder=3, label='Cantera')
    a1.set_ylabel('T [K]'); a1.set_xlabel('t [ms]')
    a1.set_xlim(-0.02 * tmax, tmax * 1.02); a1.set_xticks(xt); a1.set_ylim(*ylimT)
    a1.legend(loc=legend_loc, handlelength=1.3, handletextpad=0.4)
    for s, c, (lx, ly) in zip(species, cols, label_pos):
        i = sl.index(s)
        m = ref[:, i].max()
        a2.plot(t, pr[:, i] / m, color=c, lw=3, zorder=2)
        a2.plot(t[::every], ref[::every, i] / m, ls='', marker='o', ms=6.5, mfc='white', mec=c, mew=1.5, zorder=3)
        lab = s.replace('2', '$_2$').replace('4', '$_4$')
        a2.text(lx, ly, lab, color=c, fontsize=FS, fontfamily='Roboto Medium', transform=a2.transAxes, ha='right', va='center')
    a2.set_ylabel('Y / max Y$_{\\rm Cantera}$', labelpad=2); a2.set_xlabel('t [ms]')
    a2.set_xlim(-0.02 * tmax, tmax * 1.02); a2.set_xticks(xt); a2.set_ylim(-0.04, 1.2)
    a2.set_yticks([0, 0.5, 1.0])


def pt_axes(f, x, y, w, h, W, H):
    """axes from a box given in pt (x, y from lower-left)"""
    return f.add_axes([x / W, y / H, w / W, h / H])


def h2_figure():
    W, H = 736, 272
    f = fig(W, H)
    a1 = pt_axes(f, 84, 52, 155, 202, W, H)
    a2 = pt_axes(f, 312, 52, 160, 202, W, H)
    a3 = pt_axes(f, 548, 52, 135, 190, W, H)
    traj_axes(a1, a2, 'hydrogen', ['H2O', 'OH', 'H2'], [RED, ORANGE, TU], 2, 0.6, [0, 0.3, 0.6], (1000, 2950),
              [(0.97, 0.955), (0.97, 0.50), (0.97, 0.345)])
    ign_panel(a3, D['h2_ign'], [1000, 1050, 1100, 1150, 1200])
    a3.set_ylabel('ignition delay τ [ms]', labelpad=2)
    a3.set_yticks([0.05, 0.1, 0.2, 0.3]); a3.set_yticklabels(['0.05', '0.1', '0.2', '0.3']); a3.minorticks_off()
    a3.text(1.53, 1.025, 'T$_0$ [K]', transform=a3.get_xaxis_transform(), fontsize=LEG, color=INK2, va='bottom')
    save(f, 'h2_figure')


def ch4_figure():
    W, H = 736, 290
    f = fig(W, H)
    a1 = pt_axes(f, 82, 52, 265, 228, W, H)
    a2 = pt_axes(f, 452, 52, 270, 228, W, H)
    traj_axes(a1, a2, 'methane', ['CO2', 'OH', 'CH4'], [RED, ORANGE, TU], 2, 5.0, [0, 1, 2, 3, 4, 5], (1450, 2900),
              [(0.98, 0.955), (0.98, 0.56), (0.98, 0.09)])
    save(f, 'ch4_traj')


# ================================================================ ignition delay vs phi
def ign_panel(ax, rows, T0s, labels_right=True, unit=1e3, cols=None):
    cols = cols or blues(len(T0s))
    for T0, c in zip(T0s, cols):
        r = rows[rows[:, 0] == T0]
        r = r[np.argsort(r[:, 1])]
        ax.plot(r[:, 1], r[:, 2] * unit, color=c, lw=2.2, marker='p', ms=11, mec=c, zorder=2)
        ax.plot(r[:, 1], r[:, 3] * unit, color=c, lw=0, marker='^', ms=10, mfc='white', mec=c, mew=1.8, zorder=3)
        if labels_right:
            ax.text(1.53, r[-1, 2] * unit, f'{T0:.0f}', color=c, fontsize=LEG, va='center', ha='left', fontfamily='Roboto Medium')
    ax.set_yscale('log')
    ax.set_xlabel('equivalence ratio φ'); ax.set_xticks([0.5, 1.0, 1.5]); ax.set_xlim(0.42, 1.58)


def _unused_h2_ignition():
    f = fig(345, 300)
    ax = f.add_axes([0.25, 0.165, 0.58, 0.70])
    ign_panel(ax, D['h2_ign'], [1000, 1050, 1100, 1150, 1200])
    ax.set_ylabel('ignition delay τ [ms]')
    ax.set_yticks([0.05, 0.1, 0.2, 0.3]); ax.set_yticklabels(['0.05', '0.1', '0.2', '0.3'])
    ax.minorticks_off()
    ax.text(1.53, 1.0, 'T$_0$ [K]', transform=ax.get_xaxis_transform(), fontsize=LEG, color=INK2, va='bottom')
    h = [Line2D([], [], color=INK2, marker='p', ms=11, lw=0), Line2D([], [], color=INK2, marker='^', ms=10, mfc='white', mew=1.8, lw=0)]
    f.legend(h, ['Cantera', 'ChemKAN'], loc='upper center', ncol=2, bbox_to_anchor=(0.5, 1.01),
             columnspacing=0.8, handletextpad=0.2, handlelength=1.0)
    save(f, 'h2_ignition')


def ch4_ignition():
    rows = D['ch4_ign']
    T0s = [1400, 1450, 1500, 1550, 1600, 1650]
    cols = blues(6, 0.35, 0.95)[::-1]
    f = fig(736, 260)
    a1 = f.add_axes([0.11, 0.20, 0.36, 0.68])
    a2 = f.add_axes([0.66, 0.20, 0.325, 0.75])
    ign_panel(a1, np.c_[rows[:, :2], rows[:, 2:4]], T0s, unit=1.0, cols=cols)
    a1.set_ylabel('ignition delay τ [ms]')
    a1.set_yticks([0.3, 1, 3]); a1.set_yticklabels(['0.3', '1', '3']); a1.minorticks_off()
    a1.text(1.53, 1.025, 'T$_0$ [K]', transform=a1.get_xaxis_transform(), fontsize=LEG, color=INK2, va='bottom')
    for T0, c in zip(T0s, cols):
        r = rows[rows[:, 0] == T0]
        a2.plot(r[:, 1], r[:, 4], color=c, lw=2.2, marker='p', ms=11, mec=c, zorder=2)
        a2.plot(r[:, 1], r[:, 5], color=c, lw=0, marker='^', ms=10, mfc='white', mec=c, mew=1.8, zorder=3)
    a2.set_ylabel('temperature rise [K]'); a2.set_xlabel('equivalence ratio φ')
    a2.set_xticks([0.5, 1.0, 1.5]); a2.set_xlim(0.42, 1.58); a2.set_yticks([800, 1000, 1200, 1400])
    save(f, 'ch4_ignition')


# ================================================================ 441-condition grids
def grids():
    f = fig(736, 306)
    norm = LogNorm(3e-5, 1e-1)
    cmap = plt.get_cmap('Blues')
    axes = [f.add_axes([0.105, 0.17, 0.335, 0.68]), f.add_axes([0.53, 0.17, 0.335, 0.68])]
    titles = ['H$_2$–air generalization (RQ1)', 'CH$_4$–air generalization (RQ2)']
    for ax, key, title in zip(axes, ('h2_grid', 'ch4_grid'), titles):
        g = D[key]
        T, P = np.unique(g[:, 0]), np.unique(g[:, 1])
        M = np.full((len(T), len(P)), np.nan)
        for r in g:
            M[np.searchsorted(T, r[0]), np.searchsorted(P, r[1])] = r[2]
        dT, dP = T[1] - T[0], P[1] - P[0]
        im = ax.pcolormesh(np.r_[P - dP / 2, P[-1] + dP / 2], np.r_[T - dT / 2, T[-1] + dT / 2], M,
                           cmap=cmap, norm=norm, rasterized=True)
        tr = g[(g[:, 3] == 1) & (g[:, 4] == 0)]
        ax.scatter(tr[:, 1], tr[:, 0], marker='x', s=26, lw=1.6, color='white', zorder=3)
        ho = g[g[:, 4] == 1]
        ax.scatter(ho[:, 1], ho[:, 0], marker='o', s=70, facecolor='white', edgecolor=INK, lw=1.6, zorder=4)
        ax.set_xticks([0.5, 1.0, 1.5]); ax.set_xlabel('equivalence ratio φ')
        ax.set_yticks(T[::4]); ax.set_yticklabels([f'{v:.0f}' for v in T[::4]])
        ax.set_title(title, fontsize=FS, fontfamily='Roboto Medium', pad=8)
        for s in ax.spines.values():
            s.set_visible(False)
    axes[0].set_ylabel('T$_0$ [K]')
    cax = f.add_axes([0.885, 0.17, 0.02, 0.68])
    cb = f.colorbar(im, cax=cax)
    cb.set_ticks([1e-4, 1e-3, 1e-2, 1e-1]); cb.outline.set_visible(False)
    cb.set_label('MSE (shared scale)', labelpad=2)
    save(f, 'generalization_grids')


# ================================================================ Fig. 5A style noise
def noise():
    lv = D['noise_levels']
    f = fig(736, 270)
    ax = f.add_axes([0.13, 0.20, 0.54, 0.76])
    sty = {'train': (0, (1.2, 1.4)), 'noisy': (0, (4, 2)), 'clean': '-'}
    mk = {'train': 'o', 'noisy': 's', 'clean': 'D'}
    for m, c in (('ck', TU), ('dn', ORANGE)):
        for k in ('train', 'noisy', 'clean'):
            ax.plot(lv, D[f'noise_{m}_{k}'], color=c, ls=sty[k], lw=3 if k == 'clean' else 2.4,
                    marker=mk[k], ms=7.5 if k != 'clean' else 7, mfc=c if k != 'noisy' else 'white', mec=c, mew=1.6)
    ax.set_yscale('log'); ax.set_xticks([0, 3, 5, 7, 10, 15]); ax.set_xlim(-0.5, 15.5)
    ax.set_yticks([3e-5, 1e-4, 3e-4, 1e-3, 3e-3])
    ax.set_yticklabels(['3·10$^{-5}$', '10$^{-4}$', '3·10$^{-4}$', '10$^{-3}$', '3·10$^{-3}$']); ax.minorticks_off()
    ax.set_xlabel('training-data noise [%]'); ax.set_ylabel('MSE')
    h = [Line2D([], [], color=TU, lw=3), Line2D([], [], color=ORANGE, lw=3),
         Line2D([], [], color=INK2, lw=2.4, ls=(0, (1.2, 1.4)), marker='o', ms=7),
         Line2D([], [], color=INK2, lw=2.4, ls=(0, (4, 2)), marker='s', ms=7.5, mfc='white'),
         Line2D([], [], color=INK2, lw=3, marker='D', ms=7)]
    f.legend(h, ['ChemKAN (156 p.)', 'DeepONet (308 p.)', 'train (noisy)', 'noisy test', 'noise-free test'],
             loc='center left', bbox_to_anchor=(0.69, 0.56), handlelength=2.4, labelspacing=0.55)
    save(f, 'noise')


# ================================================================ rate parity TG / MG
def parity():
    W, H = 600, 345
    f = fig(W, H)
    axes = [pt_axes(f, 88, 58, 210, 245, W, H), pt_axes(f, 382, 58, 210, 245, W, H)]
    for ax, sp in zip(axes, ('TG', 'MG')):
        tr, te = D[f'par_{sp}_train'], D[f'par_{sp}_test']
        ax.scatter(tr[:, 0], tr[:, 1], s=14, color=TU, alpha=0.55, lw=0, rasterized=True)
        ax.scatter(te[:, 0], te[:, 1], s=14, color=ORANGE, alpha=0.7, lw=0, rasterized=True)
        lo = min(tr.min(), te.min()); hi = max(tr.max(), te.max()); pad = 0.06 * (hi - lo)
        ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], color=INK2, lw=1.4, ls=(0, (4, 3)), zorder=0)
        ax.set_xlim(lo - pad, hi + pad); ax.set_ylim(lo - pad, hi + pad)
        ax.locator_params(nbins=3)
        rel = D[f'par_{sp}_rel']
        ax.text(0.0, 1.04, f'd[{sp}]/dt', transform=ax.transAxes, fontsize=FS, fontfamily='Roboto Medium', va='bottom')
        ax.text(0.97, 0.04, f'rel. RMSE\n{rel[0]:.3f} / {rel[1]:.3f}', transform=ax.transAxes, ha='right', va='bottom',
                fontsize=LEG, color=INK, linespacing=1.1)
        ax.set_xlabel('Arrhenius rate')
    axes[0].set_ylabel('ChemKAN rate')
    h = [Line2D([], [], color=TU, marker='o', ls='', ms=7), Line2D([], [], color=ORANGE, marker='o', ls='', ms=7)]
    axes[0].legend(h, ['train', 'held-out'], loc='upper left', handletextpad=0.1, borderaxespad=0.1)
    save(f, 'rate_parity_TG_MG')

biodiesel()
h2_figure()
ch4_figure()
ch4_ignition()
grids()
noise()
parity()

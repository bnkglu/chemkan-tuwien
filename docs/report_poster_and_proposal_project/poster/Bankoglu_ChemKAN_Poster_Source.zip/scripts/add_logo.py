"""Replace the dashed LOGO PLACEHOLDER of a composed poster with the research-unit logo.

The logo EPS (cairo output: vector paths only, PDF-compatible operators) is converted to a
PDF Form XObject without rasterizing, then placed right-aligned in the template's logo slot
(right edge 2316.15 pt, as the header text), top-aligned with the TU Wien Informatics wordmark on
the left (y 3191.50-3302.36 pt). Nothing else on the
page is touched.

    python add_logo.py <poster_or_header_base.pdf> <logo.eps> <out.pdf>
"""
import re
import sys

import pikepdf

SRC, EPS, OUT = sys.argv[1:4]
SCALE = float(sys.argv[4]) if len(sys.argv) > 4 else 1.25   # logo height relative to the TU wordmark
RIGHT = 2316.15                       # right edge of the header text and of the logo slot
TU_Y0, TU_H = 3191.502, 110.86011     # TU Wien Informatics wordmark: bottom and height (pt)
H = TU_H * SCALE                      # top-aligned with the wordmark, growing downwards
Y0 = TU_Y0 + TU_H - H

# ---- logo: EPS page body -> PDF Form XObject (vector)
eps = open(EPS, encoding='latin-1').read()
bb = [float(v) for v in re.search(r'%%BoundingBox:\s*([\d.\s-]+)\n', eps).group(1).split()]
body = eps[eps.index('%%EndPageSetup') + len('%%EndPageSetup'):eps.index('showpage')]
clip = re.search(r'([\d.\s-]+?)\s+rectclip', body)
body = body.replace(clip.group(0), ' ' + clip.group(1).strip() + ' re W n ')
ops = set(re.findall(r'(?<![\w./])([A-Za-z*]+)(?![\w])', body))
assert ops <= {'q', 'Q', 'cm', 'rg', 'm', 'l', 'c', 'h', 'f', 're', 'W', 'n'} | {'f*'} | {'*'}, ops

pdf = pikepdf.open(SRC)
page = pdf.pages[0]
logo = pdf.make_stream(body.encode('latin-1'))
logo.Type, logo.Subtype = pikepdf.Name.XObject, pikepdf.Name.Form
logo.BBox = pikepdf.Array(bb)
logo.Resources = pikepdf.Dictionary()

# ---- remove the placeholder: dashed [8 6] rectangle and its three grey text lines
ops_ = pikepdf.parse_content_stream(page)
start = next(i for i, (o, op) in enumerate(ops_) if str(op) == 'd' and [float(x) for x in o[0]] == [8, 6])
start -= 1                                                # the q before it
assert str(ops_[start][1]) == 'q'
end = start
blocks = 0
while blocks < 4:                                         # rect block + 3 text blocks
    if str(ops_[end][1]) == 'Q':
        blocks += 1
    end += 1
removed = ops_[start:end]
assert sum(str(op) == 'TJ' for _, op in removed) == 3 and sum(str(op) == 'S' for _, op in removed) == 1
kept = ops_[:start] + ops_[end:]

# ---- place the logo
s = H / (bb[3] - bb[1])
w = (bb[2] - bb[0]) * s
x = RIGHT - w
page.Resources.XObject[pikepdf.Name('/ResearchUnitLogo')] = logo
place = [([], pikepdf.Operator('q')),
         ([s, 0, 0, s, x - bb[0] * s, Y0 - bb[1] * s], pikepdf.Operator('cm')),
         ([pikepdf.Name('/ResearchUnitLogo')], pikepdf.Operator('Do')),
         ([], pikepdf.Operator('Q'))]
page.Contents = pdf.make_stream(pikepdf.unparse_content_stream(kept[:-1] + place + kept[-1:]))
pdf.remove_unreferenced_resources()
pdf.save(OUT, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate)
print(f'logo placed at x {x:.2f}-{RIGHT:.2f} pt, y {Y0:.2f}-{Y0 + H:.2f} pt '
      f'({w / 72 * 25.4:.1f} x {H / 72 * 25.4:.1f} mm; max 200 x 60 mm)')

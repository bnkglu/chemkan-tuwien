"""Alternative to compose.py for environments without PyMuPDF.

Takes an already composed poster (the TU Wien A0 template with this poster's header, written
by compose.py) and replaces only its body Form XObject with a newly rendered body.pdf, at the
same position. Header, logo placeholder, supervisors and page boxes stay byte-for-byte as in
the base poster.

    python compose_pikepdf.py <base_poster.pdf> <body.pdf> <out.pdf>
"""
import sys

import pikepdf

BASE, BODY, OUT = sys.argv[1:4]
pdf = pikepdf.open(BASE)
page = pdf.pages[0]
xo = page.Resources.XObject
forms = [k for k, v in xo.items() if v.get('/Subtype') == '/Form' and list(map(float, v.BBox)) == [0, 0, 2306, 2724]]
assert len(forms) == 1, forms
old = xo[forms[0]]
body = pikepdf.open(BODY)
assert [round(float(v)) for v in body.pages[0].MediaBox] == [0, 0, 2306, 2724], body.pages[0].MediaBox
new = pdf.copy_foreign(body.pages[0].as_form_xobject())
new.Matrix = old.Matrix
xo[forms[0]] = new
with pdf.open_metadata(set_pikepdf_as_editor=False) as m:
    pass
pdf.remove_unreferenced_resources()
pdf.save(OUT, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate)
print('wrote', OUT)

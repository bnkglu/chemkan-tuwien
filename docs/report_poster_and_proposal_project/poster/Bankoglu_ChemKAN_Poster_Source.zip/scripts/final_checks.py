"""Final checks on the composed poster: RQ wording, QR target, fit, page size, numbers."""
import re, sys, subprocess, json
from pathlib import Path
from tempfile import TemporaryDirectory
import pdfplumber, cv2, numpy as np
POSTER, REL = Path(sys.argv[1]), Path(sys.argv[2])
out = []
def ok(c, msg): out.append(('OK  ' if c else 'FAIL') + ' ' + msg); return c
tex = (REL / 'docs/report_poster_and_proposal_project/ChemKAN_IDP_Report/main.tex').read_text()
items = re.search(r'\\subsection\{Research questions\}.*?\\begin\{enumerate\}.*?\n(.*?)\\end\{enumerate\}', tex, re.S).group(1)
rqs = [re.sub(r'\s+', ' ', i.replace('~\\cite{Koenig_2025}', ' [1]')).strip() for i in re.findall(r'\\item (.*?)(?=\n\s*\n|\n\s*\\item|$)', items, re.S)]
p = pdfplumber.open(POSTER).pages[0]
ok([round(float(v)) for v in (p.width, p.height)] == [2395, 3382], f'page {p.width:.1f} x {p.height:.1f} pt (A0 + bleed template)')
txt = re.sub(r'\s+', ' ', p.extract_text(layout=False))
html = Path(sys.argv[3]).read_text()
spans = [re.sub(r'<[^>]+>', '', m) for m in re.findall(r'<span class="q">(.*?)</span>', html)]
words = p.extract_words()
pdfwords = ' '.join(w['text'] for w in words)
for k, q in enumerate(rqs, 1):
    ok(spans[k - 1] == q, f'RQ{k} in poster source identical to report Section 1.2')
    ok(all(w in pdfwords for w in q.split()), f'RQ{k}: every word rendered in the PDF')
for k, q in enumerate([], 1):
    ok(q in txt, f'RQ{k} exact report wording on poster: "{q[:60]}…"')
for s in ['Implementation:', 'Reproduction:', 'Extension:', 'Comparative analysis:', 'Interpretability:']:
    ok(s in txt, f'success criterion present: {s}')
for s in ['LOGO PLACEHOLDER', 'Supervisor: Ass. Prof. DI Dr. Markus Bösenhofer', 'Co-Supervisor: Univ.-Prof. Dr. Thomas Gärtner',
          'github.com/bnkglu/chemkan-tuwien', 'Code, data and results', 'Authors clarified or confirmed',
          'Our PyTorch choice', 'Train-MSE increase', '(170–180k)', '(190–200k)', 'loss spike at 200k',
          'equal colours do not imply equal errors in physical units', '0.243 / 0.279', 'Ar excluded',
          'approximate the known kinetics at sampled states']:
    flat = re.sub(r'<[^>]+>', '', html)
    ok(s in txt or s.replace(' ', '') in txt.replace(' ', '') or (s in flat and all(w in pdfwords for w in s.split())),
       f'text present: {s}')
for bad in ['FAME', 'grows with mechanism size', 'dev branch', 'idp-report', 'ChemKAN median MSE, 36', 'all runs',
            'match the known kinetics except MG', 'Supplied by the authors']:
    ok(bad not in txt, f'text absent: {bad}')
# QR
with TemporaryDirectory(prefix='chemkan-poster-qr-') as qr_dir:
    qr = Path(qr_dir) / 'qr'
    subprocess.run(['pdftoppm', '-r', '200', '-png', '-x', '4600', '-y', '8700', '-W', '900', '-H', '800', str(POSTER), str(qr)], check=True)
    img = cv2.imread(str(qr.with_name('qr-1.png')))
    if img is None:
        raise RuntimeError('could not read the rendered QR-code image')
    val, pts, _ = cv2.QRCodeDetector().detectAndDecode(img)
ok(val == 'https://github.com/bnkglu/chemkan-tuwien', f'QR decodes to {val!r}')
print('\n'.join(out)); sys.exit(any(o.startswith('FAIL') for o in out))

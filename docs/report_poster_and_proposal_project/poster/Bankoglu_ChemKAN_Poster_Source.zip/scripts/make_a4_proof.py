"""Scale the A0 poster onto one A4 page (proof print). python make_a4_proof.py <poster.pdf> <out.pdf>"""
import sys
import pikepdf
SRC, OUT = sys.argv[1:3]
src = pikepdf.open(SRC)
out = pikepdf.new()
W, H = 595.276, 841.89
out.add_blank_page(page_size=(W, H))
pg = out.pages[0]
form = out.copy_foreign(src.pages[0].as_form_xobject())
bb = [float(v) for v in src.pages[0].MediaBox]
s = min(W / (bb[2] - bb[0]), H / (bb[3] - bb[1]))
x = (W - (bb[2] - bb[0]) * s) / 2; y = (H - (bb[3] - bb[1]) * s) / 2
pg.Resources = pikepdf.Dictionary(XObject=pikepdf.Dictionary(P=form))
pg.Contents = out.make_stream(f'q {s:.6f} 0 0 {s:.6f} {x:.3f} {y:.3f} cm /P Do Q'.encode())
out.save(OUT)
print(f'A4 proof, scale {s:.4f} ({1 / s:.2f}x reduction)')

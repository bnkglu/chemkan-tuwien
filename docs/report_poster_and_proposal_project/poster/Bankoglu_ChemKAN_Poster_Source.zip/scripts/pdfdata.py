"""Read plotted data back out of the repository's own matplotlib vector PDFs.

The report figures were saved as vector PDFs next to the PNGs. Every line and marker keeps its
exact page coordinates, so the data can be recovered by calibrating each axes from its tick
marks and tick labels. Used only where the release stores no table of the plotted values;
every recovered series is checked against a recorded number (see make_poster_figures.py).
"""
import math
import re

import numpy as np
import pdfplumber


def _num(s):
    s = s.replace('−', '-').replace('–', '-').strip()
    return float(s)


class Axes:
    def __init__(self, box, xmap, ymap):
        self.box = box            # x0, top, x1, bottom (page coords)
        self.xmap, self.ymap = xmap, ymap

    def inside(self, pts, pad=2.0):
        x0, t, x1, b = self.box
        return all(x0 - pad <= x <= x1 + pad and t - pad <= y <= b + pad for x, y in pts)

    def data(self, pts):
        a = np.asarray(pts, float)
        return np.c_[self.xmap(a[:, 0]), self.ymap(a[:, 1])]


def _fit(pos, val, log):
    pos, val = np.asarray(pos, float), np.asarray(val, float)
    v = np.log10(val) if log else val
    A = np.polyfit(pos, v, 1)
    res = np.abs(np.polyval(A, pos) - v).max()
    assert res < 1e-2 * max(1.0, np.ptp(v)), ('tick calibration failed', pos, val, res)
    if log:
        return lambda p: 10 ** np.polyval(A, p)
    return lambda p: np.polyval(A, p)


def _labels_near(words, axis, pos, edge, side):
    """tick label word closest to a tick at `pos` on the given side of the axes edge."""
    best = None
    for w in words:
        if axis == 'x':
            c = (w['x0'] + w['x1']) / 2
            if not (edge < w['top'] < edge + 25):
                continue
            d = abs(c - pos)
        else:
            c = (w['top'] + w['bottom']) / 2
            if not (edge - 12 < w['x1'] < edge + 1):
                continue
            d = abs(c - pos)
        if d < 8 and (best is None or d < best[0]):
            best = (d, w)
    return best[1] if best else None


def _parse_label(w, chars):
    t = w['text'].replace('−', '-')
    m = re.fullmatch(r'-?\d+(\.\d+)?', t)
    if m:
        return float(t), False
    # mathtext power of ten, e.g. "10" followed by a raised "-3" (separate smaller chars)
    if t.startswith('10'):
        sup = t[2:]
        if not sup:
            # exponent chars just above/right of the word
            ex = ''.join(c['text'] for c in chars
                         if w['x1'] - 1 <= c['x0'] <= w['x1'] + 15 and c['bottom'] < w['bottom'] and c['top'] > w['top'] - 10)
            sup = ex
        sup = sup.replace('−', '-')
        if re.fullmatch(r'-?\d+', sup):
            return 10.0 ** int(sup), True
    return None, None


def axes_list(page, min_size=40):
    """Calibrated Axes for every framed axes on the page."""
    words = page.extract_words(keep_blank_chars=False, use_text_flow=False, extra_attrs=['size'])
    chars = page.chars
    out = []
    frames = [r for r in page.rects if r['width'] > min_size and r['height'] > min_size
              and r['width'] < page.width * 0.99]
    for r in frames:
        x0, t, x1, b = r['x0'], r['top'], r['x1'], r['bottom']
        xt = sorted({round(l['x0'], 2) for l in page.lines
                     if abs(l['x0'] - l['x1']) < 0.01 and abs(l['top'] - b) < 0.6 and 1 < l['bottom'] - l['top'] < 6
                     and x0 - 0.5 <= l['x0'] <= x1 + 0.5})
        yt = sorted({round(l['top'], 2) for l in page.lines
                     if abs(l['top'] - l['bottom']) < 0.01 and abs(l['x1'] - x0) < 0.6 and 1 < l['x1'] - l['x0'] < 6
                     and t - 0.5 <= l['top'] <= b + 0.5})
        maps = []
        for axis, ticks, edge in (('x', xt, b), ('y', yt, x0)):
            pos, val, logs = [], [], []
            for p in ticks:
                w = _labels_near(words, axis, p, edge + (3 if axis == 'x' else -2), None)
                if w is None:
                    continue
                v, lg = _parse_label(w, chars)
                if v is None:
                    continue
                pos.append(p); val.append(v); logs.append(lg)
            if len(pos) < 2:
                maps.append(None); continue
            if not any(logs):
                # matplotlib may draw the minus sign as a separate glyph object that has no text;
                # restore signs: values grow to the right (x) or upwards (y, page 'top' decreases).
                order = np.argsort(pos) if axis == 'x' else np.argsort(pos)[::-1]
                v = np.array(val)[order]
                if not np.all(np.diff(v) > 0) and 0.0 in v:
                    z = int(np.where(v == 0.0)[0][0])
                    v[:z] = -np.abs(v[:z])
                    val = list(np.empty_like(v));
                    for i, o in enumerate(order):
                        val[o] = v[i]
            maps.append(_fit(pos, val, any(logs)))
        out.append(Axes((x0, t, x1, b), *maps))
    return out


def series(page, ax, npts=None, color=None, tol=1e-3):
    """Polylines inside `ax` (optionally with given point count / stroke colour), as data."""
    res = []
    for c in page.curves:
        if npts is not None and len(c['pts']) != npts:
            continue
        if color is not None:
            sc = c.get('stroking_color')
            if sc is None:
                continue
            sc = tuple(sc) if isinstance(sc, (list, tuple)) else (sc,)
            if len(sc) != len(color) or max(abs(a - b) for a, b in zip(sc, color)) > tol:
                continue
        if ax.inside(c['pts']):
            res.append(ax.data(c['pts']))
    return res


def marker_centres(page, ax, npts=None, color=None, fill=True, tol=1e-3):
    """Centres of marker glyphs (small closed paths) inside `ax`."""
    res = []
    for c in page.curves:
        if npts is not None and len(c['pts']) != npts:
            continue
        if c['x1'] - c['x0'] > 15 or c['bottom'] - c['top'] > 15:
            continue
        col = c.get('non_stroking_color') if fill else c.get('stroking_color')
        if color is not None:
            if col is None:
                continue
            col = tuple(col) if isinstance(col, (list, tuple)) else (col,)
            if len(col) != len(color) or max(abs(a - b) for a, b in zip(col, color)) > tol:
                continue
        cx, cy = (c['x0'] + c['x1']) / 2, (c['top'] + c['bottom']) / 2
        if ax.inside([(cx, cy)]):
            res.append((cx, cy))
    return ax.data(res) if res else np.zeros((0, 2))

"""Read every number the poster states from the release artifacts (no training, no model runs)."""
import csv, json, statistics as st, sys
from pathlib import Path
import numpy as np

R = Path(sys.argv[1])            # release root
E = R / 'results'
out = {}
def j(p): return json.load(open(E / p))

# ---------------- biodiesel noise runs
lv = [0, 1, 2, 3, 5, 7, 10, 15]
ck_clean, ck_train, dn_clean = {}, {}, {}
for p in lv:
    m = j(f'biodiesel/chemkan_figure_runs/fig05/chemkan_noise{p:02d}_seed0/metrics.json')['final_parameters']['tight_solver_rtol1e-10']
    ck_clean[p], ck_train[p] = m['val_mse'], m['train_mse']
    f = j(f'biodiesel/deeponet_figure_runs/fig05/deeponet_noise{p:02d}_seed0/metrics.json')['figure_normalization']
    dn_clean[p] = f['test_clean_mse_fig']
out['bio_clean'] = {p: (ck_clean[p], dn_clean[p], 'DeepONet lower' if dn_clean[p] < ck_clean[p] else 'ChemKAN lower') for p in lv}
out['bio_ck_ratio_15_0'] = ck_clean[15] / ck_clean[0]
out['bio_dn_over_ck_10'] = dn_clean[10] / ck_clean[10]
out['bio_dn_over_ck_15'] = dn_clean[15] / ck_clean[15]
out['bio_inc_0_1'] = ck_train[1] - ck_train[0]
out['bio_inc_0_5'] = ck_train[5] - ck_train[0]
cfg = j('biodiesel/chemkan_figure_runs/fig05/chemkan_noise00_seed0/config.json')
out['bio_params'] = cfg['architecture']['parameter_count']
out['bio_dn_params'] = [j(f'biodiesel/deeponet_figure_runs/fig05/deeponet_noise15_seed0/config.json').get(k) for k in ('parameters', 'parameter_count')]
out['bio_dn_lr_act'] = {k: v for k, v in j('biodiesel/deeponet_figure_runs/fig05/deeponet_noise15_seed0/config.json').items() if k in ('learning_rate', 'activation', 'lr', 'variant', 'trunk_activation', 'branch_activation')}
# scaling
H, P = [2, 3, 4, 9, 11], []
tr, te = [], []
for h in H:
    d = Path(E / f'biodiesel/chemkan_figure_runs/fig04/chemkan_h{h:02d}_seed0')
    m = json.load(open(d / 'metrics.json'))['final_parameters']['tight_solver_rtol1e-10']
    c = json.load(open(d / 'config.json'))['architecture']['parameter_count']
    P.append(c); tr.append(m['train_mse']); te.append(m['val_mse'])
fit = lambda x, y: -np.polyfit(np.log10(x), np.log10(y), 1)[0]
out['bio_scaling'] = dict(params=P, smallest=(tr[0], te[0]), order_train=fit(P[:-1], tr[:-1]), order_test=fit(P[:-1], te[:-1]))
# rate parity
rp = j('biodiesel/interpretability/summary.json')['rate_parity_all_reference_states']
out['bio_rate_parity'] = {k: (round(v['train']['relative_rmse'], 3), round(v['test']['relative_rmse'], 3), v['train']['n_states'], v['test']['n_states']) for k, v in rp.items()}

# ---------------- hydrogen
e = j('hydrogen/eval/S2_seed0_200k.json')
out['h2_eval_keys'] = list(e.keys())[:20]
g = j('hydrogen/tables/main_S2_seed0_200k_float64_rtol1e-10_generalization_441.json')
out['h2_441'] = (g['conditions'], g['training'], g['held_out'], g['mse_time_avg_median'], g['mse_time_avg_min'], g['mse_time_avg_max'], g['solver'])
rows = list(csv.DictReader(open(E / 'hydrogen/tables/main_S2_seed0_200k_float64_rtol1e-10_generalization_441.csv')))
ho = [r for r in rows if r['is_held_out'] == 'True']
out['h2_heldout_441csv'] = float(ho[0]['trajectory_mse_time_avg'])
byT = {}
for r in rows: byT.setdefault(float(r['T0_K']), []).append(float(r['trajectory_mse_time_avg']))
out['h2_T_rows_above_1e-3'] = {T: sum(v > 1e-3 for v in vs) for T, vs in byT.items() if any(v > 1e-3 for v in vs)}
out['h2_median_987.5'] = st.median(byT[987.5]); out['h2_median_1050'] = st.median(byT[1050.0])
out['h2_share_below_1e-3'] = sum(float(r['trajectory_mse_time_avg']) <= 1e-3 for r in rows) / len(rows)
ig = j('hydrogen/tables/hydrogen_ignition_delay_main_S2_seed0_200k_float64_rtol1e-10.json')
out['h2_ign'] = (ig['evaluated_conditions'], ig['median_abs_relative_delay_error'], ig['median_model_temperature_rise_K'], ig['median_reference_temperature_rise_K'], ig['solver'])
ig2 = j('hydrogen/tables/hydrogen_ignition_delay_main_S2_seed0_200k.json')
out['h2_ign_fig08b_png_source'] = (ig2['median_abs_relative_delay_error'], ig2['median_model_temperature_rise_K'], ig2.get('solver'))
hc = j('hydrogen/S2_seed0_200k/config.json')
out['h2_params'] = hc['architecture']['parameter_count']
fig07 = list(csv.DictReader(open(E / 'hydrogen/tables/fig07_per_state_mse_200k_float64_rtol1e-10.csv')))
out['h2_fig07_tight'] = [(r['condition'], r['role'], r['case_MSE_time_avg']) for r in fig07]

# ---------------- methane
mc = j('methane/S2_seed0/config.json')
out['ch4_params'] = mc['architecture']['parameter_count']
mg = j('methane/generalization/methane_grid_441.json')
out['ch4_441'] = mg['mse_time_avg']; out['ch4_ign_441'] = mg['ignition_delay_abs_rel_err']; out['ch4_ckpt'] = mg['checkpoint']
mrows = list(csv.DictReader(open(E / 'methane/generalization/methane_grid_441.csv')))
from collections import Counter
out['ch4_groups'] = Counter(r['group'] for r in mrows)
coarse = [r for r in mrows if abs((float(r['T0']) - 1400) % 50) < 1e-9 and min(abs(float(r['phi']) - p) for p in (0.5, 0.7, 0.9, 1.1, 1.3, 1.5)) < 1e-9]
out['ch4_36_n'] = len(coarse)
out['ch4_36_median_mse'] = st.median(float(r['mse_time_avg']) for r in coarse)
out['ch4_36_median_ign'] = st.median(abs(float(r['delay_rel_err'])) for r in coarse)
out['ch4_36_max_ign'] = max(abs(float(r['delay_rel_err'])) for r in coarse)
h = np.genfromtxt(E / 'methane/S2_seed0/stage2_history.csv', delimiter=',', names=True)
ep, mse = h['epoch'].astype(int), h['mse_time_avg']
out['ch4_hist_median_170001_180000'] = float(np.median(mse[(ep >= 170001) & (ep <= 180000)]))
out['ch4_hist_median_190001_200000'] = float(np.median(mse[(ep >= 190001) & (ep <= 200000)]))
out['ch4_hist_last_epoch'] = int(ep.max())
nm = np.load(R / 'chemkan/data/generated/methane.npz')
out['ch4_species'] = int(nm['species'].shape[0]); out['ch4_window_s'] = float(nm['t'][-1]); out['ch4_npts'] = int(nm['t'].shape[0])
nh = np.load(R / 'chemkan/data/generated/hydrogen.npz')
out['h2_species'] = [str(s) for s in nh['species']] if 'species' in nh.files else nh.files
out['h2_window_s'] = float(nh['t'][-1]); out['h2_npts'] = int(nh['t'].shape[0])

# ---------------- benchmark
b = list(csv.DictReader(open(E / 'inference_benchmark/results_table.csv')))
def row(system, impl, method, sub, tol):
    r = [x for x in b if x['system'] == system and x['implementation'] == impl and x['method'] == method and sub in x['solver'] and x['rtol / atol'] == tol]
    assert len(r) == 1; return r[0]
bench = {}
for s in ['hydrogen', 'methane']:
    c, a = row(s, 'Python', 'reference', 'Cantera', '1e-9 / 1e-15'), row(s, 'Julia', 'reference', 'Arrhenius', '1e-9 / 1e-15')
    pt, jl = row(s, 'Python', 'ChemKAN', 'PyTorch', '1e-6 / 1e-8'), row(s, 'Julia', 'ChemKAN', 'OrdinaryDiffEq', '1e-6 / 1e-8')
    bench[s] = {k: float(v['latency median [s]']) * 1e3 for k, v in dict(cantera=c, arrh=a, pt=pt, jl=jl).items()}
    bench[s].update(pt_x=(float(pt['speed-up latency vs Cantera ref.']), float(pt['speed-up latency vs Julia ref.'])),
                    jl_x=(float(jl['speed-up latency vs Cantera ref.']), float(jl['speed-up latency vs Julia ref.'])),
                    mse_36=float(jl['MSE median (all)']), mse_36_pt=float(pt['MSE median (all)']))
bb = {r['method'] + '|' + r['implementation'] + '|' + r['solver'] + '|' + r['rtol / atol']: float(r['latency median [s]']) * 1e3 for r in b if r['system'] == 'biodiesel'}
bench['biodiesel'] = bb
out['bench'] = bench
res = json.load(open(E / 'inference_benchmark/hydrogen/results.json'))
out['bench_machine'] = {k: res[k] for k in res if k in ('machine', 'hardware', 'platform', 'threads', 'repetitions', 'warmup')}
# mechanisms
import yaml
for mech in ['h2o2.yaml', 'gri30.yaml']:
    y = yaml.safe_load(open(E / 'inference_benchmark/julia/mechanism' / mech))
    out[mech] = dict(species=len(y['species']), reactions=len(y['reactions']))
json.dump(out, open(sys.argv[2], 'w'), indent=1, default=str)
print(json.dumps(out, indent=1, default=str))

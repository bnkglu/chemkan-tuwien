"""Collect the plotted data for the poster figures from the release, and check each series
against a recorded number before it is used. No training and no model is run.

    python poster_data.py <release-root> <out.npz>

Sources (all inside the release):
  H2 / CH4 trajectories  results/inference_benchmark/julia/inputs_{hydrogen,methane}.npz
                         `torch_pred_0` = PyTorch ChemKAN prediction of the selected checkpoint
                         (H2 S2_seed0_200k/stage2_final.pt, CH4 archive/..._epoch180000.pt; SHA-256
                         recorded in results/inference_benchmark/{hydrogen,methane}/results.json),
                         rtol/atol 1e-6/1e-8; `reference` = Cantera (identical to the dataset).
  H2 ignition delay      results/hydrogen/tables/hydrogen_ignition_delay_main_S2_seed0_200k_float64_rtol1e-10.csv
  CH4 ignition delay     results/methane/figures/methane_ignition_delay_rise_S2_epoch180000.pdf (vector)
  H2 / CH4 441 grids     results/hydrogen/tables/main_S2_seed0_200k_float64_rtol1e-10_generalization_441.csv,
                         results/methane/generalization/methane_grid_441.csv
  biodiesel Fig. 6       results/biodiesel/figures/fig06_profiles_15pct.pdf (vector)
  biodiesel Fig. 5A      results/biodiesel/figures/fig05a_noise.pdf (vector) + run metrics.json
  rate parity            results/biodiesel/interpretability/fig3_rate_parity.pdf (vector) + summary.json
"""
import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pdfplumber

sys.path.insert(0, str(Path(__file__).parent))
import pdfdata as pdd  # noqa: E402

R = Path(sys.argv[1]).resolve()
E = R / 'results'
OUT = {}
LOG = []


def check(name, got, want, rtol):
    ok = abs(got - want) <= rtol * abs(want)
    LOG.append(f"{'OK ' if ok else 'BAD'} {name}: got {got:.6g}, recorded {want:.6g} (rtol {rtol:g})")
    assert ok, LOG[-1]


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


# ------------------------------------------------------------------ H2 / CH4 trajectories
for sysn, ckpt, want_ho, want_med in (
        ('hydrogen', 'results/hydrogen/S2_seed0_200k/stage2_final.pt', None, None),
        ('methane', 'results/methane/S2_seed0/archive/stage2_S2_seed0_epoch180000.pt', None, None)):
    res = json.load(open(E / f'inference_benchmark/{sysn}/results.json'))
    assert res['checkpoint_sha256'] == sha(R / ckpt), f'{sysn}: benchmark checkpoint differs from {ckpt}'
    LOG.append(f'OK  {sysn}: torch_pred_0 comes from {ckpt} (SHA-256 {res["checkpoint_sha256"][:12]}…, {res["checkpoint_epochs"]} epochs)')
    I = np.load(E / f'inference_benchmark/julia/inputs_{sysn}.npz')
    D = np.load(R / f'chemkan/data/generated/{sysn}.npz')
    assert list(I['chemkan_tols'][0]) == [1e-6, 1e-8]
    ref, pred = I['reference'], I['torch_pred_0']             # (time, condition, state)
    assert np.abs(ref.transpose(1, 0, 2) - D['states']).max() < 1e-4
    te = int(np.where(I['is_test'])[0][0])
    rng = I['u_max'] - I['u_min']
    mse = (((pred - ref) / rng) ** 2).mean(axis=(0, 2))
    OUT[f'{sysn}_t'] = I['t']
    OUT[f'{sysn}_ref'] = ref[:, te, :]
    OUT[f'{sysn}_pred'] = pred[:, te, :]
    OUT[f'{sysn}_species'] = np.array([str(s) for s in D['species']])
    OUT[f'{sysn}_T0phi'] = np.array([I['T0'][te], I['phi'][te]])
    OUT[f'{sysn}_heldout_mse'] = mse[te]
    OUT[f'{sysn}_median36_mse'] = np.median(mse)
    LOG.append(f'    {sysn} held-out T0={I["T0"][te]:.0f} K phi={I["phi"][te]}; state layout {str(D["state_layout"])[:60]}')

# recorded values for the held-out MSE (float64, rtol 1e-10 evaluations)
h2rows = list(csv.DictReader(open(E / 'hydrogen/tables/main_S2_seed0_200k_float64_rtol1e-10_generalization_441.csv')))
h2_ho_rec = float([r for r in h2rows if r['is_held_out'] == 'True'][0]['trajectory_mse_time_avg'])
check('H2 held-out MSE (1150 K, phi 1.3), plotted prediction vs 441-grid record', float(OUT['hydrogen_heldout_mse']), h2_ho_rec, 0.02)
mg = json.load(open(E / 'methane/generalization/methane_grid_441.json'))
check('CH4 held-out MSE (1550 K, phi 1.3), plotted prediction vs 441-grid record', float(OUT['methane_heldout_mse']),
      mg['mse_time_avg']['held_out_1550K_phi1.3'], 0.02)
bt = list(csv.DictReader(open(E / 'inference_benchmark/results_table.csv')))
for sysn in ('hydrogen', 'methane'):
    r = [x for x in bt if x['system'] == sysn and x['method'] == 'ChemKAN' and 'PyTorch' in x['solver'] and x['rtol / atol'] == '1e-6 / 1e-8'][0]
    check(f'{sysn} median MSE over 36 conditions vs benchmark table', float(OUT[f'{sysn}_median36_mse']), float(r['MSE median (all)']), 1e-3)

# ------------------------------------------------------------------ H2 ignition delay (30 conditions)
rows = list(csv.DictReader(open(E / 'hydrogen/tables/hydrogen_ignition_delay_main_S2_seed0_200k_float64_rtol1e-10.csv')))
rows = [r for r in rows if r['status'] == 'evaluated']
OUT['h2_ign'] = np.array([[float(r['T0_K']), float(r['phi']), float(r['reference_delay_s']), float(r['chemkan_delay_s'])] for r in rows])
ig = json.load(open(E / 'hydrogen/tables/hydrogen_ignition_delay_main_S2_seed0_200k_float64_rtol1e-10.json'))
assert len(rows) == ig['evaluated_conditions'] == 30
rel = np.abs(OUT['h2_ign'][:, 3] - OUT['h2_ign'][:, 2]) / OUT['h2_ign'][:, 2]
check('H2 median |rel. ignition-delay error|, 30 conditions', float(np.median(rel)), ig['median_abs_relative_delay_error'], 1e-6)
OUT['h2_ign_med'], OUT['h2_ign_max'] = np.median(rel), rel.max()

# ------------------------------------------------------------------ 441-condition grids
OUT['h2_grid'] = np.array([[float(r['T0_K']), float(r['phi']), float(r['trajectory_mse_time_avg']),
                            r['is_training'] == 'True', r['is_held_out'] == 'True'] for r in h2rows])
g = json.load(open(E / 'hydrogen/tables/main_S2_seed0_200k_float64_rtol1e-10_generalization_441.json'))
check('H2 441-grid median MSE', float(np.median(OUT['h2_grid'][:, 2])), g['mse_time_avg_median'], 1e-9)
mrows = list(csv.DictReader(open(E / 'methane/generalization/methane_grid_441.csv')))
OUT['ch4_grid'] = np.array([[float(r['T0']), float(r['phi']), float(r['mse_time_avg']),
                             r['group'] == 'training', r['group'] == 'held-out'] for r in mrows])
uns = np.array([float(r['mse_time_avg']) for r in mrows if r['group'] != 'training'])
check('CH4 median MSE on 406 unseen conditions', float(np.median(uns)), mg['mse_time_avg']['unseen_406']['median'], 1e-9)
assert len(uns) == 406 and sum(r['group'] == 'training' for r in mrows) == 35
assert sum(r['is_training'] == 'True' for r in h2rows) == 35 and len(h2rows) == 441

# ------------------------------------------------------------------ CH4 ignition delay + rise (36 conditions)
p = pdfplumber.open(E / 'methane/figures/methane_ignition_delay_rise_S2_epoch180000.pdf').pages[0]
axs = sorted(pdd.axes_list(p), key=lambda a: a.box[0])
phis = np.array([0.5, 0.7, 0.9, 1.1, 1.3, 1.5])
ign = {}
for name, ax in zip(('delay_ms', 'rise_K'), axs):
    lines = [(c, ax.data(c['pts'])) for c in p.curves if len(c['pts']) == 6 and ax.inside(c['pts'])
             and c.get('stroking_color') not in (None, 0, '0', (0,), [0]) and c.get('non_stroking_color') in (1.0, (1.0,), [1.0], 1)]
    for c, d in lines:
        assert np.allclose(d[:, 0], phis, atol=0.01), d[:, 0]
        col = tuple(np.round(c['stroking_color'], 4))
        kind = 'model' if c.get('dash') and c['dash'][0] else 'ref'
        ign.setdefault(col, {}).setdefault(name, {})[kind] = d[:, 1]
cols = sorted(ign, key=lambda c: -ign[c]['delay_ms']['ref'][0])   # longest delay = 1400 K
assert len(cols) == 6 and all(len(ign[c]['delay_ms']) == 2 and len(ign[c]['rise_K']) == 2 for c in cols), ign.keys()
T0s = [1400, 1450, 1500, 1550, 1600, 1650]
OUT['ch4_ign'] = np.array([[T0, ph, ign[c]['delay_ms']['ref'][k], ign[c]['delay_ms']['model'][k],
                            ign[c]['rise_K']['ref'][k], ign[c]['rise_K']['model'][k]]
                           for T0, c in zip(T0s, cols) for k, ph in enumerate(phis)])
relm = np.abs(OUT['ch4_ign'][:, 3] - OUT['ch4_ign'][:, 2]) / OUT['ch4_ign'][:, 2]
# recorded: the methane notebook's saved output for this figure
nb = json.load(open(R / 'chemkan/notebooks/methane_extension.ipynb'))
import re
txt = [''.join(o.get('text', '')) for c in nb['cells'] if c['cell_type'] == 'code'
       and 'methane_ignition_delay_rise_S2_epoch' in ''.join(c['source']) for o in c.get('outputs', [])]
txt = [t for t in txt if '|delay error|' in t][-1]
m = re.search(r'median ([\d.]+)%, max ([\d.]+)%', txt)
check('CH4 median |rel. ignition-delay error| (36 conditions) recovered from the figure vs notebook output',
      round(100 * float(np.median(relm)), 1), float(m.group(1)), 0.05)
check('CH4 max |rel. ignition-delay error| (36 conditions)', round(100 * float(relm.max()), 1), float(m.group(2)), 0.05)
OUT['ch4_ign_med'], OUT['ch4_ign_max'] = float(m.group(1)) / 100, float(m.group(2)) / 100
LOG.append('    notebook output: ' + txt.strip().replace('\n', ' | ')[:300])

# ------------------------------------------------------------------ biodiesel Fig. 6 (15 % noise, test row 24)
p = pdfplumber.open(E / 'biodiesel/figures/fig06_profiles_15pct.pdf').pages[0]
axs = sorted(pdd.axes_list(p), key=lambda a: (round(a.box[1]), a.box[0]))
GREY, RED, GREEN = (0.35,), (0.862745098, 0.0784313725, 0.2352941176), (0.1803921569, 0.5450980392, 0.3411764706)
bio = {'truth': [], 'chemkan': [], 'deeponet': [], 'noisy': []}
for ax in axs:
    for k, col in (('truth', GREY), ('chemkan', RED), ('deeponet', GREEN)):
        s = pdd.series(p, ax, npts=30, color=col)
        assert len(s) == 1
        bio[k].append(s[0])
    mk = pdd.marker_centres(p, ax, npts=10)
    tg = bio['truth'][-1][:, 0]
    mk = mk[np.min(np.abs(mk[:, :1] - tg[None, :]), axis=1) < 0.02]   # drop the legend's sample marker
    mk = mk[np.argsort(mk[:, 0])]
    assert len(mk) == 30, len(mk)
    bio['noisy'].append(mk)
tgrid = bio['truth'][0][:, 0]
for k in bio:
    bio[k] = np.stack([a[:, 1] for a in bio[k]], 1)       # (30 times, 6 species)
cfg = json.load(open(E / 'biodiesel/chemkan_figure_runs/fig05/chemkan_noise15_seed0/config.json'))
src = cfg['data_source']
rngb = np.array(src['species_max']) - np.array(src['species_min'])
for model, want in (('chemkan', 3.44e-4), ('deeponet', 7.32e-4)):
    got = float(np.mean(((bio[model] - bio['truth']) / rngb) ** 2))
    check(f'biodiesel Fig. 6 {model} MSE on this trajectory (recovered curves) vs report caption', got, want, 0.02)
OUT['bio_t'] = np.round(tgrid, 2)
for k in bio:
    OUT['bio_' + k] = bio[k]
OUT['bio_species'] = np.array(['TG', 'ROH', 'DG', 'MG', 'GL', "R′CO₂R"])

# ------------------------------------------------------------------ biodiesel Fig. 5A (noise)
lv = [0, 1, 2, 3, 5, 7, 10, 15]
rec = {}
for p_ in lv:
    m = json.load(open(E / f'biodiesel/chemkan_figure_runs/fig05/chemkan_noise{p_:02d}_seed0/metrics.json'))['final_parameters']['tight_solver_rtol1e-10']
    f = json.load(open(E / f'biodiesel/deeponet_figure_runs/fig05/deeponet_noise{p_:02d}_seed0/metrics.json'))['figure_normalization']
    rec.setdefault('ck_train', []).append(m['train_mse']); rec.setdefault('ck_clean', []).append(m['val_mse'])
    rec.setdefault('dn_train', []).append(f['train_mse_fig']); rec.setdefault('dn_clean', []).append(f['test_clean_mse_fig'])
    rec.setdefault('dn_noisy', []).append(f['test_noisy_mse_fig'])
p = pdfplumber.open(E / 'biodiesel/figures/fig05a_noise.pdf').pages[0]
hexrgb = lambda h: tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
COL = {'ck_train': '#D2BD45', 'ck_noisy': '#4786B8', 'ck_clean': '#D92F35',
       'dn_train': '#A76540', 'dn_noisy': '#EF8426', 'dn_clean': '#55AD5B'}
page_y = {}
for k, h in COL.items():
    cs = [c for c in p.curves if len(c['pts']) == 8 and c.get('stroking_color') is not None
          and np.allclose(c['stroking_color'], hexrgb(h), atol=2e-3)]
    assert len(cs) == 1, (k, len(cs))
    page_y[k] = np.array([y for _, y in cs[0]['pts']])
# calibrate the log axis from the five series whose values metrics.json records
ys = np.concatenate([page_y[k] for k in rec]); vs = np.log10(np.concatenate([rec[k] for k in rec]))
A = np.polyfit(ys, vs, 1)
resid = np.abs(np.polyval(A, ys) - vs).max()
LOG.append(f'OK  Fig. 5A log-axis calibration from 40 recorded points: max residual {resid:.2e} decades')
assert resid < 2e-3
noise = {k: 10 ** np.polyval(A, page_y[k]) for k in COL}
for k in rec:
    noise[k] = np.array(rec[k])           # exact recorded values where recorded
assert np.isclose(noise['ck_noisy'][0], rec['ck_clean'][0], rtol=0.01)   # 0 % noise: noisy test = clean test
OUT['noise_levels'] = np.array(lv)
for k, v in noise.items():
    OUT['noise_' + k] = v
r10, r15 = noise['dn_clean'][6] / noise['ck_clean'][6], noise['dn_clean'][7] / noise['ck_clean'][7]
LOG.append(f'    clean-test DeepONet/ChemKAN at 10 % = {r10:.2f}, 15 % = {r15:.2f}; DeepONet lower at ' +
           ', '.join(f'{l} %' for l, a, b in zip(lv, noise['dn_clean'], noise['ck_clean']) if a < b))

# ------------------------------------------------------------------ rate parity (TG, MG)
p = pdfplumber.open(E / 'biodiesel/interpretability/fig3_rate_parity.pdf').pages[0]
axs = sorted(pdd.axes_list(p), key=lambda a: (round(a.box[1]), a.box[0]))
summ = json.load(open(E / 'biodiesel/interpretability/summary.json'))['rate_parity_all_reference_states']
names = ['TG', 'ROH', 'DG', 'MG', 'GL', 'RCO2R']
for i, nm in enumerate(names):
    ax = axs[i]
    pts = [c for c in p.curves if len(c['pts']) == 10 and c['x1'] - c['x0'] < 3 and str(c.get('non_stroking_color')) == '0' and  # legend samples carry their own colour
           ax.inside([((c['x0'] + c['x1']) / 2, (c['top'] + c['bottom']) / 2)])]
    xy = ax.data([((c['x0'] + c['x1']) / 2, (c['top'] + c['bottom']) / 2) for c in pts])
    assert len(xy) == 900, (nm, len(xy))
    tr, te_ = xy[:600], xy[600:]
    for split, a in (('train', tr), ('test', te_)):
        rm = float(np.sqrt(np.mean((a[:, 1] - a[:, 0]) ** 2)))
        check(f'rate parity {nm} {split} RMSE (recovered points, first 600 = train)', rm, summ[nm][split]['rmse_mol_per_L_s'], 0.03)
    if nm in ('TG', 'MG'):
        OUT[f'par_{nm}_train'], OUT[f'par_{nm}_test'] = tr, te_
        OUT[f'par_{nm}_rel'] = np.array([summ[nm]['train']['relative_rmse'], summ[nm]['test']['relative_rmse']])

np.savez(sys.argv[2], **OUT)
print('\n'.join(LOG))
Path(sys.argv[2]).with_suffix('.log').write_text('\n'.join(LOG) + '\n')

# ChemKAN IDP poster — final source

Old-poster arrangement with the content checked against the final report. Figures are
drawn at their printed size (17–22 pt text) from data in the release. Nothing is
retrained and no new trajectories are integrated. `verify_mg_initial_states.py` evaluates the
existing biodiesel checkpoint (in NumPy) at the recorded reference states.

## Rebuild

```bash
REL=/path/to/chemkan-release
python scripts/verify.py        $REL build/verify.json              # numbers quoted in the text
python scripts/poster_data.py   $REL build/fig/poster_data.npz      # plotted data + checks (log: build/fig/poster_data.log)
python scripts/make_poster_figures.py build/fig/poster_data.npz fonts build/fig
python scripts/build_body.py    $REL build                          # fills build/body.html, renders build/body.pdf (Chromium)
# compose — either (needs PyMuPDF; writes the header from the template):
python scripts/compose.py tpl/Poster_Template.pdf fonts build/body.pdf poster.pdf
# or (pikepdf only; reuses the header of tpl/header_base_poster.pdf, the previous composed poster):
python scripts/compose_pikepdf.py tpl/header_base_poster.pdf build/body.pdf poster.pdf
python scripts/add_logo.py poster.pdf tpl/logo/ICEBE_TU_Logo_Corrected_RGB.eps poster_logo.pdf   # replaces the logo placeholder
python scripts/export_eps.py poster_logo.pdf poster_logo.eps        # vector EPS
python scripts/final_checks.py poster_logo.pdf $REL build/body.html      # RQ wording, criteria, QR, notation
python scripts/verify_mg_initial_states.py $REL build/mg_initial_state_check.json   # MG t0 breakdown (read-only, no torch)
```

Edit text in `build/body.html`; edit figures in `scripts/make_poster_figures.py`.
`build/body_figure_swap_previous.html` is the previous version (the “Minimal Figure Swap”), kept for comparison.
Dependencies: NumPy, Matplotlib, pdfplumber and PyYAML; Playwright with Chromium to render
the body (WeasyPrint is the fallback). Composition needs PyMuPDF (`compose.py`) or pikepdf
(`compose_pikepdf.py`). `add_logo.py` and `export_eps.py` need pikepdf; `export_eps.py`
also needs pdfplumber, Pillow and Poppler's `pdftops`. The QR code is generated with segno,
qrcode or OpenCV. `final_checks.py` needs OpenCV (`opencv-python`) and Poppler's `pdftoppm`
on PATH. `verify_mg_initial_states.py` imports the release's biodiesel data generator, which
needs SciPy.

Use `poster_logo.pdf` (the output of `add_logo.py`) as the distributed PDF. The EPS is only
for print shops that require EPS; a PDF converted back from it loses its text layer
(no ToUnicode maps) and its TrimBox.

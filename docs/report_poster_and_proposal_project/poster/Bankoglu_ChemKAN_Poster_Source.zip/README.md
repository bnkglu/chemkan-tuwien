# ChemKAN IDP poster — editable source

A0 portrait poster (TU Wien Informatics template, 841 × 1189 mm with 2 mm bleed) for
*Modeling Chemical Kinetics with ChemKANs: Reproduction in PyTorch and Extension to Methane*.
All numbers and plotted data are read from the ChemKAN release (`chemkan-tuwien`) and checked
against recorded results. Nothing is retrained, and no new simulation is run.

## Layout

| Row | Left | Middle | Right |
|---|---|---|---|
| Intro | Context & CRISP-DM workflow | ChemKAN in one picture (paper's Fig. 2, original asset) | Data |
| RQ1 Reproduction | Biodiesel, 15 % noise | H₂–air trajectories + ignition delay | What did ChemKAN learn? (biodiesel rate parity) |
| RQ2 Methane extension | CH₄–air held-out trajectory | Ignition delay + temperature rise | 441-condition generalization (H₂ and CH₄) |
| RQ3 Comparison | Noise robustness vs DeepONet | Inference time + references | Overall conclusions + QR code |

## Files

- **`build/body.html`:** all poster text and layout (CSS at the top). Placeholders `{{…}}` are filled from the release by `build_body.py`.
- **`build/fig/*.svg`:** figures drawn at print size by `scripts/make_poster_figures.py` from `build/fig/poster_data.npz`.
- **`build/img/chemkan_architecture_paper_fig2_1831px.png`:** Fig. 2 of Koenig et al. (CC BY-NC 4.0), used unchanged.
- **`tpl/`:**
  - `Poster_Template.pdf`: TU Wien A0 template.
  - `header_base_poster.pdf`: the template with this poster's header.
  - `logo/`: research-unit logo (ICEBE / TU Wien).
- **`fonts/`:** Roboto Light, Light Italic and Medium (Apache License 2.0).

## Rebuild

Needs Python with numpy, matplotlib, pdfplumber, pikepdf, playwright + Chromium, and opencv-python (or segno / qrcode); also poppler (`pdftoppm`, `pdftops`).

```bash
REL=/path/to/chemkan-release
python scripts/verify.py        $REL build/verify.json            # numbers quoted in the text
python scripts/poster_data.py   $REL build/fig/poster_data.npz    # plotted data + checks (log: build/fig/poster_data.log)
python scripts/make_poster_figures.py build/fig/poster_data.npz fonts build/fig
python scripts/build_body.py    $REL build                        # fills body.html, renders build/body.pdf
python scripts/compose_pikepdf.py tpl/header_base_poster.pdf build/body.pdf poster_nologo.pdf
#   (alternative with PyMuPDF: python scripts/compose.py tpl/Poster_Template.pdf fonts build/body.pdf poster_nologo.pdf)
python scripts/add_logo.py poster_nologo.pdf tpl/logo/ICEBE_TU_Logo_Corrected_RGB.eps poster.pdf 1.25
python scripts/final_checks.py  poster.pdf $REL build/body.html   # RQ wording, key phrases, QR target
python scripts/export_eps.py    poster.pdf poster.eps             # vector EPS for print
python scripts/make_a4_proof.py poster.pdf poster_A4_proof.pdf    # A4 proof print
python scripts/verify_mg_initial_states.py $REL build/mg_initial_state_check.json   # optional, read-only
```

## Data sources and checks

| Figure / number | Source in the release | Check |
|---|---|---|
| H₂ / CH₄ trajectories | `results/inference_benchmark/julia/inputs_*.npz` (PyTorch predictions of `S2_seed0_200k` and `epoch180000` checkpoints; SHA-256 verified) | held-out MSE 3.507·10⁻⁴ / 1.163·10⁻³ = recorded |
| H₂ ignition delay | `results/hydrogen/tables/hydrogen_ignition_delay_main_S2_seed0_200k_float64_rtol1e-10.csv` | median 1.36 % = recorded |
| CH₄ ignition delay / rise | `results/methane/figures/methane_ignition_delay_rise_S2_epoch180000.pdf` (vector) | median 1.2 %, max 5.8 % = notebook output |
| 441-condition maps | H₂ and CH₄ generalization CSVs | medians 4.91·10⁻⁴ / 9.21·10⁻⁴ = recorded |
| Biodiesel profiles | `results/biodiesel/figures/fig06_profiles_15pct.pdf` (vector) | trajectory MSE 3.44·10⁻⁴ / 7.32·10⁻⁴ = report |
| Noise robustness | `fig05a_noise.pdf` + run `metrics.json` | 2.71× / 2.73× at 10 / 15 % |
| Rate parity | `results/biodiesel/interpretability/fig3_rate_parity.pdf` + `summary.json` | all 12 RMSEs within 0.1 % |
| Timing table | `results/inference_benchmark/results_table.csv` | — |

Additionally, `verify_mg_initial_states.py` shows that 30 of the 900 parity states have zero reference MG rate. All 30 are t = 0 states, and they carry 76.2 % of the pooled MG squared error. Excluding them, the MG relative RMSE is 0.101 (train) and 0.166 (held-out).

## Revision history

1. **Old-poster arrangement:**
   - All figures are redrawn at print size from release data.
   - Research questions use the exact wording of report §1.2.
   - Methane uses the epoch-180,000 checkpoint, and the two heatmaps share one colour scale.
2. **Scientific wording:**
   - Methane training MSE is given as window medians.
   - The author-clarified settings are separated from our t_ref choice.
   - The MSE row was removed from the timing table.
   - The MG initial-state finding was added.
   - Heatmap note: equal colours do not mean equal physical errors.
3. **Header and links:**
   - The ICEBE / TU Wien logo is placed at 1.25× the height of the faculty logo.
   - The QR code points to `https://bnkglu.github.io/chemkan-tuwien/` (EC level M, 4-module quiet zone).
   - Two link lines were added: website, and code / data / runs.
4. **Readability (supervisor feedback):**
   - The bottom row was removed. The biodiesel interpretability panel moved to RQ1, and the overall conclusions to RQ3.
   - Success criteria, “What it took to reproduce” and the takeaways were removed; the key paper-vs-ours biodiesel numbers moved under the biodiesel figure.
   - Text is now 21–26 pt (captions 22.5 pt), and figure text 20–23 pt.
   - The architecture figure is the original asset, unchanged.
